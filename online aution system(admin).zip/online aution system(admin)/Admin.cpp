#include <iostream>
#include "Admin.h"
#include <string>
using namespace std;

Admin::Admin(char pname[], char padmin_id[], char ppassword[])
{
  strcpy(name, pname);
  strcpy(admin_id, padmin_id);
  strcpy(password, ppassword);
}
void Admin::add_admin()
{
  
}
void Admin::add_auction() 
{
  
}
void Admin::remove_auction() 
{
  
}
