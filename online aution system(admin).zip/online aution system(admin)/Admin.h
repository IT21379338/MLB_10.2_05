#include <iostream>
#include<string>
using namespace std;

class Admin
{
private:
  char name[30];
  char admin_id[5];
  char password[8];
public:
  Admin(char pname[], char padmin_id[], char ppassword[]);
  void add_admin();
  void add_auction();
  void remove_auction();
  
  
};
